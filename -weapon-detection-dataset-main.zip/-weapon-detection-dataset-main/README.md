# Weapon Detection Dataset (Merged)

Merged dataset combining two sources into one unified YOLOv8-format dataset, with no duplicate or overlapping images.

## Sources
- **Roboflow** (`weapon-detection-revmd-7k7ai`) — 176 labeled images across 18 weapon classes
- **Kaggle** (Guns Dataset by Sasank Yadati) — 302 unique images (31 exact duplicates removed), converted from pixel-corner bounding box format to normalized YOLO format, mapped to the `pistol` class

## Notes
- 18 unlabeled images from the Roboflow `valid` split were excluded
- Dataset was re-shuffled and re-split 80/10/10 (train/valid/test) after merging
- No duplicate images exist within or across the two source datasets (verified via MD5 hashing)

## Structure
```
merged_dataset/
├── data.yaml
├── train/images, train/labels   (382 images)
├── valid/images, valid/labels   (47 images)
└── test/images, test/labels     (49 images)
```

## Classes (18)
0, 1, 2, Celurit, Linggis, axe, cleaver, heavyweapon, katana, knife, mace, pistol, rifle, rocket launcher, scope, smg, sniper rifle, sword

## Training
```bash
pip install ultralytics
yolo detect train data=data.yaml model=yolov8n.pt epochs=50 imgsz=640
```
